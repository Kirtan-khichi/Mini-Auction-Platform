import React from "react";
import AddItem from "../components/AddItem"; 

const AddItemPage = () => {
  return (
    <div>
      <AddItem /> 
    </div>
  );
};

export default AddItemPage;
